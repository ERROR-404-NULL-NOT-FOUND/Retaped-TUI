# Retaped-TUI
A shitty TUI Revolt client (real). Also currently the only TUI Revolt client
