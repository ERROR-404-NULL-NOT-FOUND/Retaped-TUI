def run():
    from . import main